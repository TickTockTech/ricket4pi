'''
Created on 26 Apr 2018

@author: sasho
'''
import movement as move, robohat

robohat.init()
move.init()

move.forward(3, 30)
